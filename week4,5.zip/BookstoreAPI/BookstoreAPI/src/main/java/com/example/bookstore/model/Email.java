package com.example.bookstore.model;

public @interface Email {

}
