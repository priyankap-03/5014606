package com.example.bookstore.model;

public @interface NotNull {

}
