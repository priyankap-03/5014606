package com.example.bookstore.controller;

import java.util.Optional;

import com.example.bookstore.model.Book;

public class Mockito {

	public static Object when(Optional<Book> optional) {
		// TODO Auto-generated method stub
		return null;
	}

	public static Mockito doNothing() {
		// TODO Auto-generated method stub
		return null;
	}

	public static Object any(Class<Book> class1) {
		// TODO Auto-generated method stub
		return null;
	}

}
