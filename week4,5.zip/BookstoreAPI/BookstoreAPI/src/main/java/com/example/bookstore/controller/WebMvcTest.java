package com.example.bookstore.controller;

public @interface WebMvcTest {

	Class<BookController> value();

}
