package com.example.bookstore.controller;

public class MockMvc {

}
