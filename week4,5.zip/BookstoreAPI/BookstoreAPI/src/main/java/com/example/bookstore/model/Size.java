package com.example.bookstore.model;

public @interface Size {

	int min();

	int max();

}
