package com.example.bookstore.controller;

public @interface MockBean {

}
