package com.example.bookstore.model;

public @interface Min {

	int value();

}
