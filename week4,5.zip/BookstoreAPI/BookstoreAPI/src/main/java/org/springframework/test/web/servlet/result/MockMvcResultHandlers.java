package org.springframework.test.web.servlet.result;

public class MockMvcResultHandlers {

}
