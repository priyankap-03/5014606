package org.springframework.boot.test.autoconfigure.web.servlet;

public @interface AutoConfigureMockMvc {

}
