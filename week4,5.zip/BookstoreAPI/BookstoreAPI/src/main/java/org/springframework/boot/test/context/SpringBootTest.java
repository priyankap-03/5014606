package org.springframework.boot.test.context;

public @interface SpringBootTest {

}
